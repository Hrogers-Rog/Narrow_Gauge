using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Core;
using FUSE.Authoring.Data;
using FUSE.Runtime.API;
using FUSE.Runtime.Events;
using Track;
using UnityEngine;

namespace NarrowGaugeMod
{
    /// <summary>
    /// Fuse companion lifecycle, gauge metadata cache, and generated ghost graph
    /// synchronization coordinator.
    /// </summary>
    public class NarrowGaugeManager : MonoBehaviour
    {
        private static readonly HashSet<string> ExplicitNarrowSegmentIds =
            new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        private static readonly HashSet<string> ExplicitDualGaugeSegmentIds =
            new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        private static readonly HashSet<string> GeneratedGhostSegmentIds =
            new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        private static ShadowNarrowGaugeGraph? CurrentShadowGraph;
        private static string LastValidationSignature = string.Empty;
        private static string LastAuthoringIssueSignature = string.Empty;

        private bool _synchronizing;
        private bool _syncRequested;

        private void Awake()
        {
            DontDestroyOnLoad(gameObject);
            FuseEvents.TrackGraphApplying += HandleTrackGraphApplying;
            FuseEvents.GraphRebuilt += HandleFuseGraphRebuilt;
            FuseEvents.FuseUnloaded += HandleFuseUnloaded;
            Main.Log("FUSE Narrow Gauge manager awake.");
        }

        private void Start()
        {
            StartCoroutine(WaitForGraphAndSynchronize());
        }

        private void LateUpdate()
        {
            if (!_syncRequested || _synchronizing)
            {
                return;
            }

            Graph graph = Graph.Shared;
            if (graph == null || !graph.HasPopulatedCollections)
            {
                return;
            }

            _syncRequested = false;
            SynchronizeOutsideFuseRebuild(graph, "deferred graph synchronization");
        }

        private void OnDestroy()
        {
            FuseEvents.TrackGraphApplying -= HandleTrackGraphApplying;
            FuseEvents.GraphRebuilt -= HandleFuseGraphRebuilt;
            FuseEvents.FuseUnloaded -= HandleFuseUnloaded;
            DualGaugeLinkRegistry.Clear();
            SpecialWorkRuntimeRegistry.Clear();
        }

        private IEnumerator WaitForGraphAndSynchronize()
        {
            var wait = new WaitForSeconds(0.5f);
            while (true)
            {
                Graph graph = Graph.Shared;
                if (graph != null && graph.HasPopulatedCollections)
                {
                    SynchronizeOutsideFuseRebuild(graph, "initial module synchronization");
                    yield break;
                }

                yield return wait;
            }
        }

        private void HandleTrackGraphApplying(FuseTrackGraphApplyingContext context)
        {
            if (_synchronizing || context?.Graph == null)
            {
                return;
            }

            _synchronizing = true;
            try
            {
                GhostGraphSynchronizationResult result = GhostGraphSynchronizer.Synchronize(context.Graph);
                SpecialWorkTopologySynchronizationResult specialWork =
                    Main.Settings?.EnableSpecialWorkTopology == false
                        ? new SpecialWorkTopologySynchronizationResult()
                        : SpecialWorkTopologySynchronizer.Synchronize(context.Graph);
                RefreshGaugeMetadata(context.Graph);
                _syncRequested = false;
                LogSynchronization(result, "Fuse pre-rebuild");
                LogSpecialWorkSynchronization(specialWork, "Fuse pre-rebuild");
            }
            finally
            {
                _synchronizing = false;
            }
        }

        private void HandleFuseGraphRebuilt()
        {
            Graph graph = Graph.Shared;
            if (graph != null)
            {
                ScanGraph(graph);
            }

            // This also catches graph rebuilds initiated outside TrackAPI. The
            // deferred pass is idempotent and requests another rebuild only if
            // generated topology actually changed.
            _syncRequested = true;
        }

        private void HandleFuseUnloaded()
        {
            ExplicitNarrowSegmentIds.Clear();
            ExplicitDualGaugeSegmentIds.Clear();
            GeneratedGhostSegmentIds.Clear();
            CurrentShadowGraph = null;
            LastAuthoringIssueSignature = string.Empty;
            DualGaugeSharedRailRegistry.Clear();
            DualGaugeLinkRegistry.Clear();
            SpecialWorkRuntimeRegistry.Clear();
        }

        private void SynchronizeOutsideFuseRebuild(Graph graph, string reason)
        {
            if (_synchronizing)
            {
                return;
            }

            _synchronizing = true;
            GhostGraphSynchronizationResult result;
            SpecialWorkTopologySynchronizationResult specialWork;
            TrackAPI.BeginBatch();
            try
            {
                result = GhostGraphSynchronizer.Synchronize(graph);
                specialWork = Main.Settings?.EnableSpecialWorkTopology == false
                    ? new SpecialWorkTopologySynchronizationResult()
                    : SpecialWorkTopologySynchronizer.Synchronize(graph);
                RefreshGaugeMetadata(graph);
            }
            finally
            {
                TrackAPI.EndBatch(true);
                _synchronizing = false;
            }

            LogSynchronization(result, reason);
            LogSpecialWorkSynchronization(specialWork, reason);
        }

        private static void LogSynchronization(GhostGraphSynchronizationResult result, string reason)
        {
            if (result.HasChanges || result.DualGaugeSources > 0)
            {
                Main.Log($"Ghost graph synchronization ({reason}): {result}");
            }
        }

        private static void LogSpecialWorkSynchronization(
            SpecialWorkTopologySynchronizationResult result,
            string reason)
        {
            if (result.HasChanges || result.NarrowBranchTransitions > 0 || result.Issues.Count > 0)
            {
                Main.Log($"Special-work topology synchronization ({reason}): {result}");
            }

            foreach (string issue in result.Issues.Take(8))
            {
                Main.Warn("  " + issue);
            }
        }

        public static void RequestSynchronization()
        {
            NarrowGaugeManager manager = FindObjectOfType<NarrowGaugeManager>();
            if (manager != null)
            {
                manager._syncRequested = true;
            }
        }

        public static void ScanGraph(Graph graph)
        {
            if (graph == null)
            {
                return;
            }

            RefreshGaugeMetadata(graph);
            RebuildShadowGraph(graph);
            DualGaugeSwitchSynchronizer.SynchronizeAll(graph);
            RebuildSpecialWorkAnalyses(graph);

            int visibleNarrow = graph.Segments.Count(segment =>
                IsNarrowGauge(segment) && !IsGeneratedGhost(segment));
            int dual = graph.Segments.Count(IsDualGauge);
            int ghosts = graph.Segments.Count(IsGeneratedGhost);

            if (visibleNarrow > 0 || dual > 0 || ghosts > 0)
            {
                Main.Log(
                    $"Gauge graph: narrow={visibleNarrow}, dual={dual}, " +
                    $"generatedGhosts={ghosts}, links={DualGaugeLinkRegistry.Links.Count}.");
            }

            LogValidationChanges(GaugeGraphValidator.Validate(graph));
        }

        public static void RefreshGaugeMetadata(Graph graph)
        {
            ExplicitNarrowSegmentIds.Clear();
            ExplicitDualGaugeSegmentIds.Clear();
            GeneratedGhostSegmentIds.Clear();

            if (graph == null)
            {
                return;
            }

            foreach (TrackSegment segment in graph.Segments)
            {
                if (segment == null || string.IsNullOrWhiteSpace(segment.id))
                {
                    continue;
                }

                if (GhostGraphSynchronizer.IsGeneratedGhostSegmentId(segment.id))
                {
                    GeneratedGhostSegmentIds.Add(segment.id);
                    ExplicitNarrowSegmentIds.Add(segment.id);
                    continue;
                }

                FuseSegment definition = TrackAPI.GetSegmentDefinition(segment.id);
                if (GhostGraphSynchronizer.IsDualGaugeDefinition(definition))
                {
                    ExplicitDualGaugeSegmentIds.Add(segment.id);
                }
                else if (GhostGraphSynchronizer.IsNarrowGaugeDefinition(definition))
                {
                    ExplicitNarrowSegmentIds.Add(segment.id);
                }
            }
        }

        public static bool HasExplicitNarrowGauge(TrackSegment? segment)
        {
            return segment != null
                && !string.IsNullOrEmpty(segment.id)
                && ExplicitNarrowSegmentIds.Contains(segment.id);
        }

        public static bool IsNarrowGauge(TrackSegment? segment)
        {
            return HasExplicitNarrowGauge(segment)
                || IsNarrowTurntableBridge(segment);
        }

        public static bool IsDualGauge(TrackSegment? segment)
        {
            return segment != null
                && !string.IsNullOrEmpty(segment.id)
                && ExplicitDualGaugeSegmentIds.Contains(segment.id);
        }

        public static bool IsGeneratedGhost(TrackSegment? segment)
        {
            return segment != null
                && !string.IsNullOrEmpty(segment.id)
                && GeneratedGhostSegmentIds.Contains(segment.id);
        }

        public static bool IsGeneratedGhostNode(TrackNode? node)
        {
            return node != null && GhostGraphSynchronizer.IsGeneratedGhostNodeId(node.id);
        }

        private static bool IsNarrowTurntableBridge(TrackSegment? segment)
        {
            if (segment == null
                || segment.turntable == null
                || segment.style != TrackSegment.Style.Bridge)
            {
                return false;
            }

            return TurntableBridgeEndTouchesExplicitNarrowGauge(segment, segment.a)
                || TurntableBridgeEndTouchesExplicitNarrowGauge(segment, segment.b);
        }

        private static bool TurntableBridgeEndTouchesExplicitNarrowGauge(
            TrackSegment bridgeSegment,
            TrackNode? node)
        {
            if (node == null || Graph.Shared == null)
            {
                return false;
            }

            return Graph.Shared.SegmentsConnectedTo(node)
                .Any(connected => connected != null
                    && connected != bridgeSegment
                    && HasExplicitNarrowGauge(connected));
        }

        internal static ShadowNarrowGaugeGraph? GetShadowGraph()
        {
            return CurrentShadowGraph;
        }

        internal static ShadowNarrowGaugeTransition? GetShadowTransition(TrackNode? node)
        {
            if (node == null
                || CurrentShadowGraph == null
                || string.IsNullOrEmpty(node.id))
            {
                return null;
            }

            return CurrentShadowGraph.Transitions.TryGetValue(node.id, out ShadowNarrowGaugeTransition transition)
                ? transition
                : null;
        }

        public static void RebuildShadowGraph(Graph graph)
        {
            try
            {
                CurrentShadowGraph = ShadowNarrowGaugeGraphBuilder.Build(graph);
            }
            catch (Exception ex)
            {
                CurrentShadowGraph = null;
                Main.Warn($"Failed to build narrow-gauge geometry shadow graph: {ex.Message}");
            }
        }

        private static void RebuildSpecialWorkAnalyses(Graph graph)
        {
            try
            {
                IReadOnlyList<SpecialWorkDefinition> definitions =
                    SpecialWorkRuntimeDiscovery.Discover(graph);
                SpecialWorkAuthoringSnapshot authoring = SpecialWorkAuthoring.Load();
                definitions = SpecialWorkAuthoring.Apply(
                    definitions,
                    authoring,
                    out IReadOnlyList<string> authoringIssues);
                SpecialWorkAnalysis[] analyses = definitions
                    .Select(definition => SpecialWorkGeometryAnalyzer.Analyze(graph, definition))
                    .ToArray();
                SpecialWorkRuntimeRegistry.Replace(analyses);
                LogAuthoringIssues(authoring, authoringIssues);

                int invalid = analyses.Count(analysis => analysis.ValidationIssues.Count > 0);
                if (analyses.Length > 0)
                {
                    Main.Log($"Special-work analysis: objects={analyses.Length}, invalid={invalid}.");
                }

                foreach (SpecialWorkAnalysis analysis in analyses
                    .Where(item => item.MeshPlan != null))
                {
                    SpecialWorkMeshPlan plan = analysis.MeshPlan!;
                    Main.Log(
                        $"Special-work plan '{analysis.Definition.Id}' ({analysis.Definition.Preset.Id}): " +
                        $"valid={plan.IsValid}, rails={analysis.Rails.Count}, " +
                        $"shared={analysis.SharedRailIntervals.Count}, " +
                        $"intersections={analysis.Intersections.Count}, cuts={plan.Cuts.Count}, " +
                        $"fixed={plan.FixedRunningRails.Count}, frogs={plan.Frogs.Count}, " +
                        $"wings={plan.WingRails.Count}, guards={plan.GuardRails.Count}, " +
                        $"blades={plan.SwitchBlades.Count}.");
                }

                foreach (SpecialWorkAnalysis analysis in analyses
                    .Where(item => item.ValidationIssues.Count > 0)
                    .Take(6))
                {
                    Main.Warn(
                        $"Special-work FIRST FAILURE '{analysis.Definition.Id}': " +
                        analysis.ValidationIssues.First());
                    Main.Warn(
                        $"Special-work '{analysis.Definition.Id}' ({analysis.Definition.Preset.Id}) " +
                        $"has {analysis.ValidationIssues.Count} validation issue(s).");
                    foreach (string issue in analysis.ValidationIssues.Take(4))
                    {
                        Main.Warn("  " + issue);
                    }
                }
            }
            catch (Exception ex)
            {
                SpecialWorkRuntimeRegistry.Clear();
                Main.Warn($"Failed to rebuild special-work analysis: {ex.Message}");
            }
        }

        private static void LogAuthoringIssues(
            SpecialWorkAuthoringSnapshot authoring,
            IReadOnlyList<string> issues)
        {
            IReadOnlyList<string> safeIssues = issues ?? Array.Empty<string>();
            string signature = string.Join(
                "\n",
                safeIssues.OrderBy(issue => issue, StringComparer.Ordinal));
            if (string.Equals(signature, LastAuthoringIssueSignature, StringComparison.Ordinal))
            {
                return;
            }

            LastAuthoringIssueSignature = signature;
            if (authoring.Bindings.Count > 0)
            {
                Main.Log(
                    $"Special-work authoring: bindings={authoring.Bindings.Count}, issues={safeIssues.Count}.");
            }

            foreach (string issue in safeIssues.Take(12))
            {
                Main.Warn("Special-work authoring: " + issue);
            }
        }

        private static void LogValidationChanges(GaugeGraphValidationReport report)
        {
            string signature = string.Join("\n", report.Issues.OrderBy(issue => issue, StringComparer.Ordinal));
            if (string.Equals(signature, LastValidationSignature, StringComparison.Ordinal))
            {
                return;
            }

            LastValidationSignature = signature;
            if (report.IsValid)
            {
                Main.Log("Gauge graph validation passed.");
                return;
            }

            Main.Warn($"Gauge graph validation found {report.Issues.Count} issue(s).");
            foreach (string issue in report.Issues.Take(12))
            {
                Main.Warn("  " + issue);
            }
        }
    }
}
