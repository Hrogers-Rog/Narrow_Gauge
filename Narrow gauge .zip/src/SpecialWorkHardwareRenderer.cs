using System;
using System.Collections.Generic;
using System.Linq;
using Core;
using Track;
using UnityEngine;

namespace NarrowGaugeMod
{
    /// <summary>
    /// Renders only validated measured mesh plans. Graph routing and native
    /// switch-point animation remain owned by the base game.
    /// </summary>
    internal static class SpecialWorkHardwareRenderer
    {
        private const float PhysicalOverlapTolerance = 0.06f;
        private const float OverlapSampleSpacing = 0.08f;
        private const float MinimumOverlapLength = 0.18f;
        private const float MinimumRailPieceLength = 0.06f;
        private const float OwnershipSeamOverlap = 0.12f;
        private const float TieOverlapTolerance = 1.0f;
        private const float TieOwnershipMargin = 0.35f;

        public static bool HasValidPlan(TrackNode? node)
        {
            return node != null
                && SpecialWorkRuntimeRegistry.FindByNativeNodeId(node.id)?.MeshPlan?.IsValid == true;
        }

        public static bool HasTruthTable(TrackNode? node)
        {
            SpecialWorkAnalysis? analysis =
                node == null ? null : SpecialWorkRuntimeRegistry.FindByNativeNodeId(node.id);
            return analysis != null
                && SpecialWorkTruthTableCatalog.TryGet(analysis.Definition.Preset.Id, out _);
        }

        public static bool ShouldSuppressLegacySpecialWorkRails(TrackNode? node)
        {
            NarrowGaugeSettings? settings = Main.Settings;
            if (settings?.DebugShowOnlyVanillaTurnoutObjects == true
                || settings?.DebugHideVanillaInSpecialWork == false)
            {
                return false;
            }

            return HasValidPlan(node) || HasTruthTable(node);
        }

        public static bool CanRenderLegacyPointHardware(TrackNode? node)
        {
            SpecialWorkAnalysis? analysis =
                node == null ? null : SpecialWorkRuntimeRegistry.FindByNativeNodeId(node.id);
            NarrowGaugeSettings? settings = Main.Settings;
            if (settings?.DebugShowOnlyVanillaTurnoutObjects == true
                || settings?.DebugHideVanillaInSpecialWork == false)
            {
                return true;
            }

            if (analysis?.MeshPlan?.IsValid == true
                && analysis.Definition.Preset.Category == SpecialWorkCategory.DualGauge
                && analysis.MeshPlan.SwitchBlades.Count > 0)
            {
                return false;
            }

            return !HasTruthTable(node) || HasValidPlan(node);
        }

        public static bool CanRenderCustomSpecialWork(TrackNode? node)
        {
            NarrowGaugeSettings? settings = Main.Settings;
            if (settings?.EnableSpecialWorkHardware == false
                || settings?.DebugShowOnlyVanillaTurnoutObjects == true
                || settings?.DebugHideCustomRails == true)
            {
                return false;
            }

            SpecialWorkAnalysis? analysis =
                node == null ? null : SpecialWorkRuntimeRegistry.FindByNativeNodeId(node.id);
            return analysis?.MeshPlan?.IsValid == true
                || settings?.DebugShowOnlySpecialWorkObjects == true;
        }

        public static void LogVanillaSuppression(
            TrackNode? node,
            string descriptorId,
            string sourceBuilder,
            int vanillaSwitchObjects,
            int vanillaRailObjects,
            int vanillaTieObjects)
        {
            if (node == null)
            {
                return;
            }

            SpecialWorkAnalysis? analysis =
                SpecialWorkRuntimeRegistry.FindByNativeNodeId(node.id);
            SpecialWorkMeshPlan? plan = analysis?.MeshPlan;
            int customRailObjects = plan == null
                ? 0
                : plan.FixedRunningRails.Count
                    + plan.FrogPieces.Count
                    + plan.WingRails.Count
                    + plan.GuardRails.Count
                    + plan.SwitchBlades.Count;
            int customTieObjects = Main.Settings?.DebugHideCustomTies == true ? 0 : 1;
            Main.Log(
                $"[SpecialWorkSuppress] node={node.id} descriptor={descriptorId} " +
                $"source={sourceBuilder} vanillaSwitchObjects={vanillaSwitchObjects} " +
                $"vanillaRailObjects={vanillaRailObjects} vanillaTieObjects={vanillaTieObjects} " +
                $"specialWorkRailObjects={customRailObjects} specialWorkTieObjects={customTieObjects} " +
                $"planValid={plan?.IsValid.ToString() ?? "<none>"}");
        }

        public static void LogBuiltObjectCounts(
            TrackNode? node,
            string descriptorId,
            string sourceBuilder,
            Transform container)
        {
            if (node == null || container == null)
            {
                return;
            }

            Transform[] objects = container.GetComponentsInChildren<Transform>(includeInactive: true);
            string vanillaRootName = "sw-" + node.id;
            string customRootName = "measured-special-work-" + node.id;
            int vanillaSwitchObjects = objects.Count(item =>
                string.Equals(item.name, vanillaRootName, System.StringComparison.OrdinalIgnoreCase));
            int vanillaTieObjects = objects.Count(item =>
                IsUnderNamedRoot(item, vanillaRootName)
                && item.name.IndexOf("tie", System.StringComparison.OrdinalIgnoreCase) >= 0);
            int vanillaRailObjects = objects.Count(item =>
                IsUnderNamedRoot(item, vanillaRootName)
                && IsRailObjectName(item.name));
            int specialWorkRailObjects = objects.Count(item =>
                IsUnderNamedRoot(item, customRootName)
                && item != container
                && !string.Equals(item.name, customRootName, System.StringComparison.OrdinalIgnoreCase));
            int specialWorkTieObjects = objects.Count(item =>
                IsUnderNamedRoot(item, customRootName)
                && item.name.IndexOf("tie", System.StringComparison.OrdinalIgnoreCase) >= 0);
            Main.Log(
                $"[SpecialWorkObjects] node={node.id} descriptor={descriptorId} source={sourceBuilder} " +
                $"vanillaSwitchObjects={vanillaSwitchObjects} vanillaRailObjects={vanillaRailObjects} " +
                $"vanillaTieObjects={vanillaTieObjects} specialWorkRailObjects={specialWorkRailObjects} " +
                $"specialWorkTieObjects={specialWorkTieObjects}");
        }

        private static bool IsUnderNamedRoot(Transform item, string rootName)
        {
            for (Transform? current = item; current != null; current = current.parent)
            {
                if (string.Equals(current.name, rootName, System.StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }

            return false;
        }

        private static bool IsRailObjectName(string name)
        {
            string safe = name ?? string.Empty;
            return safe.IndexOf("stock", System.StringComparison.OrdinalIgnoreCase) >= 0
                || safe.IndexOf("closure", System.StringComparison.OrdinalIgnoreCase) >= 0
                || safe.IndexOf("point", System.StringComparison.OrdinalIgnoreCase) >= 0
                || safe.IndexOf("frog", System.StringComparison.OrdinalIgnoreCase) >= 0
                || safe.IndexOf("guard", System.StringComparison.OrdinalIgnoreCase) >= 0
                || safe.IndexOf("third", System.StringComparison.OrdinalIgnoreCase) >= 0
                || safe.IndexOf("middle", System.StringComparison.OrdinalIgnoreCase) >= 0
                || safe.IndexOf("outer", System.StringComparison.OrdinalIgnoreCase) >= 0;
        }

        public static IEnumerable<(float Start, float End)> OwnershipCuts(
            LineCurve worldVisibleRail,
            TrackSegment sourceSegment)
        {
            foreach (SpecialWorkAnalysis analysis in SpecialWorkRuntimeRegistry.Analyses.Where(item =>
                item.MeshPlan?.IsValid == true
                && item.Definition.Routes.Any(route =>
                    route.SourceSegmentIds.Contains(
                        sourceSegment.id,
                        StringComparer.OrdinalIgnoreCase))))
            {
                foreach (RailWorkInterval work in analysis.MeshPlan!.WorkIntervals)
                {
                    LineCurve ownedCurve = Slice(
                        work.Rail.Curve,
                        work.StartDistance,
                        work.EndDistance);
                    foreach ((float start, float end) in FindOverlapIntervals(
                        worldVisibleRail,
                        ownedCurve))
                    {
                        if (TryCreateOwnershipCut(start, end, out var cut))
                        {
                            yield return cut;
                        }
                    }
                }
            }
        }

        public static IEnumerable<(float Start, float End)> TieOwnershipCuts(
            LineCurve worldCenterline,
            TrackSegment sourceSegment)
        {
            foreach (SpecialWorkAnalysis analysis in SpecialWorkRuntimeRegistry.Analyses.Where(item =>
                item.MeshPlan?.IsValid == true
                && item.Definition.Routes.Any(route =>
                    route.SourceSegmentIds.Contains(
                        sourceSegment.id,
                        StringComparer.OrdinalIgnoreCase))))
            {
                SpecialWorkMeshPlan plan = analysis.MeshPlan!;
                foreach (LogicalRoute route in analysis.Definition.Routes.Where(route =>
                    route.SourceSegmentIds.Contains(
                        sourceSegment.id,
                        StringComparer.OrdinalIgnoreCase)))
                {
                    foreach (RailWorkInterval work in plan.WorkIntervals.Where(work =>
                        work.Rail.SourceRouteIds.Contains(route.Id, StringComparer.OrdinalIgnoreCase)))
                    {
                        LineCurve ownedCurve = Slice(
                            work.Rail.Curve,
                            work.StartDistance,
                            work.EndDistance);
                        foreach ((float start, float end) in FindOverlapIntervals(
                            worldCenterline,
                            ownedCurve,
                            TieOverlapTolerance))
                        {
                            yield return (
                                Mathf.Max(0f, start - TieOwnershipMargin),
                                Mathf.Min(worldCenterline.Length, end + TieOwnershipMargin));
                        }
                    }
                }
            }
        }

        public static IEnumerable<(float Start, float End)> OwnershipCutsForNode(
            LineCurve worldVisibleRail,
            TrackNode node)
        {
            SpecialWorkMeshPlan? plan =
                SpecialWorkRuntimeRegistry.FindByNativeNodeId(node?.id)?.MeshPlan;
            if (node == null || plan?.IsValid != true)
            {
                yield break;
            }

            foreach (RailWorkInterval work in plan.WorkIntervals)
            {
                LineCurve ownedCurve = Slice(
                    work.Rail.Curve,
                    work.StartDistance,
                    work.EndDistance);
                foreach ((float start, float end) in FindOverlapIntervals(
                    worldVisibleRail,
                    ownedCurve))
                {
                    if (TryCreateOwnershipCut(start, end, out var cut))
                    {
                        yield return cut;
                    }
                }
            }
        }

        private static bool TryCreateOwnershipCut(
            float start,
            float end,
            out (float Start, float End) cut)
        {
            float cutStart = Mathf.Min(end, start + OwnershipSeamOverlap);
            float cutEnd = Mathf.Max(cutStart, end - OwnershipSeamOverlap);
            cut = (cutStart, cutEnd);
            return cutEnd - cutStart >= MinimumRailPieceLength;
        }

        public static void AddAdditionalHardware(
            TrackObjectBuilder builder,
            TrackNode node,
            SwitchGeometry nativeGeometry,
            Transform parent)
        {
            SpecialWorkAnalysis? analysis =
                SpecialWorkRuntimeRegistry.FindByNativeNodeId(node?.id);
            SpecialWorkMeshPlan? plan = analysis?.MeshPlan;
            if (node == null
                || analysis == null
                || plan == null
                || !CanRenderCustomSpecialWork(node)
                || analysis.Definition.Preset.Category != SpecialWorkCategory.DualGauge)
            {
                if (node != null && analysis != null && plan != null)
                {
                    Main.Log(
                        $"[Build] Skipping measured special-work '{analysis.Definition.Id}' " +
                        $"node={node.id} valid={plan.IsValid} customAllowed={CanRenderCustomSpecialWork(node)} " +
                        $"issues={string.Join(" | ", plan.ValidationIssues.Take(3))}");
                }
                return;
            }

            GameObject root = NarrowGaugeTrackBuilder.CreateTrackRoot(
                builder,
                "measured-special-work-" + node.id,
                parent);
            Main.Log(
                $"[Build] Rendering measured special-work '{analysis.Definition.Id}': " +
                $"fixed={plan.FixedRunningRails.Count}, frogs={plan.Frogs.Count}, " +
                $"wings={plan.WingRails.Count}, guards={plan.GuardRails.Count}, " +
                $"blades={plan.SwitchBlades.Count}.");

            if (Main.Settings?.DebugHideCustomTies != true)
            {
                GameObject tiesRoot = NarrowGaugeTrackBuilder.CreateTrackRoot(
                    builder,
                    "SpecialWorkTies",
                    root.transform);
                NarrowGaugeTrackBuilder.CreateSpecialWorkTies(
                    builder,
                    nativeGeometry,
                    tiesRoot.transform);
            }

            int fixedIndex = 0;
            foreach (RailPiece piece in plan.FixedRunningRails)
            {
                CreateRail(
                    builder,
                    root,
                    piece.Curve,
                    nativeGeometry.switchHome,
                    "Fixed-" + fixedIndex++,
                    _ => 1f);
            }

            int bladeIndex = 0;
            foreach (SwitchBladePlan blade in plan.SwitchBlades)
            {
                CreatePointBlade(
                    builder,
                    root,
                    blade.BladeCurve,
                    nativeGeometry.switchHome,
                    "Blade-" + bladeIndex++);
            }

            int frogIndex = 0;
            foreach (FrogCandidate frog in plan.Frogs.Where(item =>
                item.Intersection.Kind == RailIntersectionKind.VeeFrogCandidate))
            {
                CreateVeeFrog(
                    builder,
                    root,
                    frog,
                    plan.SwitchBlades,
                    nativeGeometry.switchHome,
                    "VeeFrog-" + frogIndex++);
            }

            foreach (RailPiece piece in plan.FrogPieces)
            {
                FrogCandidate? frog = plan.Frogs.FirstOrDefault(item =>
                    string.Equals(item.Id, piece.SourcePlanId, StringComparison.OrdinalIgnoreCase));
                if (frog?.Intersection.Kind == RailIntersectionKind.CrossingFrogCandidate)
                {
                    CreateRail(
                        builder,
                        root,
                        piece.Curve,
                        nativeGeometry.switchHome,
                        "CrossingFrogRail-" + frogIndex,
                        _ => 1f);
                }

                frogIndex++;
            }

            int wingIndex = 0;
            foreach (WingRailPlan wing in plan.WingRails)
            {
                FrogCandidate? frog = plan.Frogs.FirstOrDefault(item =>
                    string.Equals(item.Id, wing.FrogId, StringComparison.OrdinalIgnoreCase));
                if (frog?.Intersection.Kind == RailIntersectionKind.VeeFrogCandidate
                    && !IsOnFrogNoseSide(wing.Curve, frog, plan.SwitchBlades))
                {
                    continue;
                }

                CreateRail(
                    builder,
                    root,
                    frog?.Intersection.Kind == RailIntersectionKind.VeeFrogCandidate
                        ? BendWingRailAwayFromFrog(wing.Curve, frog, plan.SwitchBlades)
                        : wing.Curve,
                    nativeGeometry.switchHome,
                    "Wing-" + wingIndex++,
                    _ => 1f);
            }

            int guardIndex = 0;
            foreach (GuardRailPlan guard in plan.GuardRails)
            {
                CreateRail(
                    builder,
                    root,
                    guard.Curve,
                    nativeGeometry.switchHome,
                    "Guard-" + guardIndex++,
                    _ => 1f);
            }
        }

        private static IEnumerable<(float Start, float End)> FindOverlapIntervals(
            LineCurve target,
            LineCurve candidate,
            float tolerance = PhysicalOverlapTolerance)
        {
            var matches = new List<float>();
            int count = Mathf.Max(
                2,
                Mathf.CeilToInt(candidate.Length / OverlapSampleSpacing) + 1);
            for (int index = 0; index < count; index++)
            {
                float candidateDistance = index == count - 1
                    ? candidate.Length
                    : Mathf.Min(candidate.Length, index * OverlapSampleSpacing);
                Vector3 point = candidate.LinePointAtDistance(candidateDistance).point;
                if (!TryDistanceAlongCurve(
                    target,
                    point,
                    out float targetDistance,
                    out float separation)
                    || separation > tolerance)
                {
                    continue;
                }

                matches.Add(targetDistance);
            }

            if (matches.Count < 3)
            {
                yield break;
            }

            matches.Sort();
            float start = matches[0];
            float previous = matches[0];
            for (int index = 1; index < matches.Count; index++)
            {
                if (matches[index] - previous <= OverlapSampleSpacing * 2.5f)
                {
                    previous = matches[index];
                    continue;
                }

                if (previous - start >= MinimumOverlapLength)
                {
                    yield return (
                        Mathf.Max(0f, start - OverlapSampleSpacing),
                        Mathf.Min(target.Length, previous + OverlapSampleSpacing));
                }

                start = matches[index];
                previous = matches[index];
            }

            if (previous - start >= MinimumOverlapLength)
            {
                yield return (
                    Mathf.Max(0f, start - OverlapSampleSpacing),
                    Mathf.Min(target.Length, previous + OverlapSampleSpacing));
            }
        }

        private static bool TryDistanceAlongCurve(
            LineCurve curve,
            Vector3 point,
            out float distanceAlong,
            out float separation)
        {
            distanceAlong = 0f;
            separation = float.MaxValue;
            float traversed = 0f;
            bool found = false;
            foreach ((int _, LineSegment segment) in curve.Segments)
            {
                Vector3 delta = segment.b.point - segment.a.point;
                float length = delta.magnitude;
                if (length <= 0.00001f)
                {
                    continue;
                }

                float t = Mathf.Clamp01(
                    Vector3.Dot(point - segment.a.point, delta) / delta.sqrMagnitude);
                Vector3 closest = segment.a.point + delta * t;
                float candidateSeparation = Vector3.Distance(point, closest);
                if (candidateSeparation < separation)
                {
                    separation = candidateSeparation;
                    distanceAlong = traversed + length * t;
                    found = true;
                }

                traversed += length;
            }

            return found;
        }

        private static LineCurve Slice(LineCurve curve, float start, float end)
        {
            float clampedStart = Mathf.Clamp(start, 0f, curve.Length);
            float clampedEnd = Mathf.Clamp(end, clampedStart, curve.Length);
            return curve.Skip(clampedStart, true).Take(clampedEnd - clampedStart);
        }

        private static void CreateRail(
            TrackObjectBuilder builder,
            GameObject root,
            LineCurve worldCurve,
            Vector3 switchHome,
            string name,
            Func<int, float> profile)
        {
            if (worldCurve == null
                || worldCurve.Points.Count() < 2
                || worldCurve.Length < MinimumRailPieceLength)
            {
                return;
            }

            Mesh mesh = NarrowGaugeTrackBuilder.BuildStockRailMesh(
                worldCurve.Offset(-switchHome),
                switchHome,
                Gauge.Standard,
                profile);
            NarrowGaugeTrackBuilder.CreateMeshObject(builder, mesh, name, root);
        }

        private static void CreatePointBlade(
            TrackObjectBuilder builder,
            GameObject root,
            LineCurve worldCurve,
            Vector3 switchHome,
            string name)
        {
            if (worldCurve == null
                || worldCurve.Points.Count() < 2
                || worldCurve.Length < MinimumRailPieceLength)
            {
                return;
            }

            LineCurve localCurve = worldCurve.Offset(-switchHome);
            LineCurve bladeCurve = ReprofilePointBlade(localCurve);
            LinePoint[] points = bladeCurve.Points.ToArray();
            if (points.Length < 2)
            {
                return;
            }

            Vector3 pivot = points.Last().point;
            LineCurve pivotedCurve = bladeCurve.Offset(-pivot);
            int pointCount = pivotedCurve.Points.Count();
            int taperPoints = Mathf.Clamp(pointCount / 2, 2, Mathf.Max(pointCount, 2));
            Mesh mesh = NarrowGaugeTrackBuilder.BuildStockRailMesh(
                pivotedCurve,
                switchHome,
                Gauge.Standard,
                i =>
                {
                    if (pointCount <= 1)
                    {
                        return 1f;
                    }

                    if (i >= taperPoints)
                    {
                        return 0.92f;
                    }

                    float t = taperPoints <= 1
                        ? 1f
                        : (float)i / (taperPoints - 1);
                    return Mathf.Lerp(0.04f, 0.92f, t * t);
                });

            GameObject rail = NarrowGaugeTrackBuilder.CreateMeshObject(builder, mesh, name, root);
            rail.transform.localPosition = pivot;
        }

        private static LineCurve ReprofilePointBlade(LineCurve curve)
        {
            if (curve.Length <= 0.3f)
            {
                return curve;
            }

            float tipTrim = Mathf.Min(0.12f, Mathf.Max(curve.Length - 0.05f, 0.01f));
            LineCurve trimmed = curve.Skip(tipTrim, false);
            if (!trimmed.Points.Any())
            {
                return curve;
            }

            LinePoint tip = trimmed.Points.First();
            float taperLength = Mathf.Min(
                Mathf.Max(trimmed.Length * 0.6f, 0.35f),
                Mathf.Max(trimmed.Length - 0.05f, 0.05f));
            LineCurve reprofiled = trimmed.Skip(taperLength, false);
            if (!reprofiled.Points.Any())
            {
                return trimmed;
            }

            reprofiled.Insert(0, tip);
            return reprofiled;
        }

        private static void CreateVeeFrog(
            TrackObjectBuilder builder,
            GameObject root,
            FrogCandidate frog,
            IReadOnlyList<SwitchBladePlan> blades,
            Vector3 switchHome,
            string name)
        {
            Vector3 noseSide = DirectionTowardBlades(frog, blades);
            LinePoint heelA = HeelPoint(
                frog.Intersection.RailA,
                frog.Intersection.DistanceA,
                frog,
                noseSide);
            LinePoint heelB = HeelPoint(
                frog.Intersection.RailB,
                frog.Intersection.DistanceB,
                frog,
                noseSide);
            LinePoint[] points =
            {
                new LinePoint(heelA.point - switchHome, heelA.Rotation),
                new LinePoint(
                    frog.Intersection.Position - switchHome,
                    Quaternion.LookRotation(-noseSide, Vector3.up)),
                new LinePoint(heelB.point - switchHome, heelB.Rotation)
            };

            Mesh mesh = NarrowGaugeTrackBuilder.BuildFrogMesh(points, Gauge.Standard);
            NarrowGaugeTrackBuilder.CreateMeshObject(builder, mesh, name, root);
        }

        private static LinePoint HeelPoint(
            RailCenterline rail,
            float intersectionDistance,
            FrogCandidate frog,
            Vector3 noseSide)
        {
            float beforeDistance = Mathf.Max(0f, intersectionDistance - frog.CutHalfLength);
            float afterDistance = Mathf.Min(rail.Curve.Length, intersectionDistance + frog.CutHalfLength);
            LinePoint before = rail.Curve.LinePointAtDistance(beforeDistance);
            LinePoint after = rail.Curve.LinePointAtDistance(afterDistance);
            Vector3 beforeDirection = before.point - frog.Intersection.Position;
            Vector3 afterDirection = after.point - frog.Intersection.Position;
            return Vector3.Dot(beforeDirection, noseSide)
                <= Vector3.Dot(afterDirection, noseSide)
                ? before
                : after;
        }

        private static Vector3 DirectionTowardBlades(
            FrogCandidate frog,
            IReadOnlyList<SwitchBladePlan> blades)
        {
            Vector3 bladeCenter = blades.Count == 0
                ? frog.Intersection.Position + frog.NoseDirection
                : blades
                    .Select(blade => blade.BladeCurve.Head.point)
                    .Aggregate(Vector3.zero, (sum, point) => sum + point) / blades.Count;
            Vector3 direction = bladeCenter - frog.Intersection.Position;
            direction.y = 0f;
            return direction.sqrMagnitude > 0.0001f
                ? direction.normalized
                : frog.NoseDirection.normalized;
        }

        private static bool IsOnFrogNoseSide(
            LineCurve curve,
            FrogCandidate frog,
            IReadOnlyList<SwitchBladePlan> blades)
        {
            Vector3 middle = curve.LinePointAtDistance(curve.Length * 0.5f).point;
            return Vector3.Dot(
                middle - frog.Intersection.Position,
                DirectionTowardBlades(frog, blades)) > 0f;
        }

        private static LineCurve BendWingRailAwayFromFrog(
            LineCurve curve,
            FrogCandidate frog,
            IReadOnlyList<SwitchBladePlan> blades)
        {
            bool headNearFrog =
                Vector3.Distance(curve.Head.point, frog.Intersection.Position)
                < Vector3.Distance(curve.Tail.point, frog.Intersection.Position);
            LineCurve oriented = headNearFrog ? curve.Reverse() : curve;
            LinePoint end = oriented.Tail;
            Vector3 tangent = end.Rotation * Vector3.forward;
            Vector3 towardHeel = -DirectionTowardBlades(frog, blades);
            Vector3 lateral = Vector3.Cross(Vector3.up, tangent).normalized;
            if (Vector3.Dot(lateral, towardHeel) > 0f)
            {
                lateral = -lateral;
            }

            oriented.Add(new LinePoint(
                end.point + lateral * 0.1f,
                end.Rotation));
            return headNearFrog ? oriented.Reverse() : oriented;
        }
    }
}
