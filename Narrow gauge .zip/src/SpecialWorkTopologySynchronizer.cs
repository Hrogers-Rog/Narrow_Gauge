using System;
using System.Collections.Generic;
using System.Linq;
using FUSE.Authoring.Data;
using FUSE.Runtime.API;
using Track;

namespace NarrowGaugeMod
{
    internal sealed class SpecialWorkTopologySynchronizationResult
    {
        public int NarrowBranchTransitions { get; set; }
        public int RewiredSegments { get; set; }
        public int RestoredSegments { get; set; }
        public List<string> Issues { get; } = new List<string>();

        public bool HasChanges => RewiredSegments > 0 || RestoredSegments > 0;

        public override string ToString()
        {
            return $"narrowBranchTransitions={NarrowBranchTransitions} " +
                   $"rewired={RewiredSegments} restored={RestoredSegments} issues={Issues.Count}";
        }
    }

    /// <summary>
    /// Compiles gauge-family boundaries that cannot be represented by leaving
    /// every authored segment attached to one native node.
    /// </summary>
    internal static class SpecialWorkTopologySynchronizer
    {
        internal const string SourceNodeTagPrefix = "fuse-ng:special-work-source-node=";
        internal const string PresetTagPrefix = "fuse-ng:special-work-preset=";

        public static SpecialWorkTopologySynchronizationResult Synchronize(Graph graph)
        {
            var result = new SpecialWorkTopologySynchronizationResult();
            if (graph == null)
            {
                return result;
            }

            TrackSegment[] allSegments = TrackAPI.GetAllSegments()
                .Where(segment => segment != null)
                .ToArray();

            foreach (TrackSegment branch in allSegments
                .Where(IsRealNarrowOnly)
                .OrderBy(segment => segment.id, StringComparer.OrdinalIgnoreCase)
                .ToArray())
            {
                string sourceNodeId = GetTaggedSourceNodeId(branch);
                if (string.IsNullOrEmpty(sourceNodeId))
                {
                    sourceNodeId = FindImplicitNarrowBranchSourceNodeId(branch, allSegments);
                }

                if (string.IsNullOrEmpty(sourceNodeId))
                {
                    continue;
                }

                TrackNode sourceNode = graph.GetNode(sourceNodeId);
                string ghostNodeId = GhostGraphSynchronizer.GetGhostNodeId(sourceNodeId);
                TrackNode ghostNode = graph.GetNode(ghostNodeId);
                bool sourceStillHasDualMain = sourceNode != null
                    && CountConnectedDualSourceSegments(sourceNode, allSegments) == 2;

                if (!sourceStillHasDualMain)
                {
                    if (sourceNode != null && SegmentTouchesNode(branch, ghostNodeId))
                    {
                        if (TryRewireSegment(
                            branch,
                            ghostNodeId,
                            sourceNodeId,
                            sourceNodeId,
                            transitionActive: false,
                            out string issue))
                        {
                            result.RestoredSegments++;
                        }
                        else if (!string.IsNullOrEmpty(issue))
                        {
                            result.Issues.Add(issue);
                        }
                    }

                    continue;
                }

                result.NarrowBranchTransitions++;
                if (ghostNode == null)
                {
                    result.Issues.Add(
                        $"Narrow branch transition at '{sourceNodeId}' has no generated narrow node '{ghostNodeId}'.");
                    continue;
                }

                if (SegmentTouchesNode(branch, ghostNodeId))
                {
                    EnsureTransitionTags(branch, sourceNodeId);
                    continue;
                }

                if (!SegmentTouchesNode(branch, sourceNodeId))
                {
                    result.Issues.Add(
                        $"Narrow branch '{branch.id}' declares transition source '{sourceNodeId}' " +
                        "but touches neither the source nor generated narrow node.");
                    continue;
                }

                if (TryRewireSegment(
                    branch,
                    sourceNodeId,
                    ghostNodeId,
                    sourceNodeId,
                    transitionActive: true,
                    out string rewireIssue))
                {
                    result.RewiredSegments++;
                }
                else if (!string.IsNullOrEmpty(rewireIssue))
                {
                    result.Issues.Add(rewireIssue);
                }
            }

            return result;
        }

        internal static string GetTaggedSourceNodeId(TrackSegment segment)
        {
            FuseSegment? definition = segment != null
                ? TrackAPI.GetSegmentDefinition(segment.id)
                : null;

            string? tag = definition?.Tags?.FirstOrDefault(value =>
                value != null
                && value.StartsWith(SourceNodeTagPrefix, StringComparison.OrdinalIgnoreCase));

            return tag == null ? string.Empty : tag.Substring(SourceNodeTagPrefix.Length);
        }

        private static string FindImplicitNarrowBranchSourceNodeId(
            TrackSegment branch,
            IReadOnlyCollection<TrackSegment> allSegments)
        {
            foreach (TrackNode endpoint in new[] { branch.a, branch.b }.Where(node => node != null))
            {
                TrackSegment[] connectedSources = allSegments
                    .Where(segment => !NarrowGaugeManager.IsGeneratedGhost(segment))
                    .Where(segment => segment.a == endpoint || segment.b == endpoint)
                    .ToArray();

                if (connectedSources.Length == 3
                    && connectedSources.Count(IsRealNarrowOnly) == 1
                    && connectedSources.Count(IsDualSource) == 2)
                {
                    return endpoint.id;
                }
            }

            return string.Empty;
        }

        private static int CountConnectedDualSourceSegments(
            TrackNode node,
            IReadOnlyCollection<TrackSegment> allSegments)
        {
            return allSegments.Count(segment =>
                IsDualSource(segment)
                && (segment.a == node || segment.b == node));
        }

        private static bool IsDualSource(TrackSegment segment)
        {
            return segment != null
                && !GhostGraphSynchronizer.IsGeneratedGhostSegmentId(segment.id)
                && GhostGraphSynchronizer.IsDualGaugeDefinition(TrackAPI.GetSegmentDefinition(segment.id));
        }

        private static bool IsRealNarrowOnly(TrackSegment segment)
        {
            if (segment == null || GhostGraphSynchronizer.IsGeneratedGhostSegmentId(segment.id))
            {
                return false;
            }

            FuseSegment definition = TrackAPI.GetSegmentDefinition(segment.id);
            return GhostGraphSynchronizer.IsNarrowGaugeDefinition(definition)
                && !GhostGraphSynchronizer.IsDualGaugeDefinition(definition);
        }

        private static bool SegmentTouchesNode(TrackSegment segment, string nodeId)
        {
            return segment != null
                && (string.Equals(segment.a?.id, nodeId, StringComparison.OrdinalIgnoreCase)
                    || string.Equals(segment.b?.id, nodeId, StringComparison.OrdinalIgnoreCase));
        }

        private static bool TryRewireSegment(
            TrackSegment segment,
            string oldNodeId,
            string newNodeId,
            string sourceNodeId,
            bool transitionActive,
            out string issue)
        {
            issue = string.Empty;
            if (IsSegmentOccupied(segment))
            {
                issue =
                    $"Deferred special-work topology update for narrow branch '{segment.id}' " +
                    "because rolling stock currently occupies it.";
                return false;
            }

            FuseSegment current = TrackAPI.GetSegmentDefinition(segment.id);
            if (current == null)
            {
                issue = $"Cannot rewire narrow branch '{segment.id}' because its FUSE definition is unavailable.";
                return false;
            }

            var replacement = Clone(current);
            if (string.Equals(replacement.StartNodeId, oldNodeId, StringComparison.OrdinalIgnoreCase))
            {
                replacement.StartNodeId = newNodeId;
            }
            else if (string.Equals(replacement.EndNodeId, oldNodeId, StringComparison.OrdinalIgnoreCase))
            {
                replacement.EndNodeId = newNodeId;
            }
            else
            {
                issue = $"Cannot rewire narrow branch '{segment.id}'; definition does not reference '{oldNodeId}'.";
                return false;
            }

            replacement.Tags = transitionActive
                ? MergeTags(
                    replacement.Tags,
                    SourceNodeTagPrefix + sourceNodeId,
                    PresetTagPrefix + SpecialWorkPresetIds.DualNarrowBranch)
                : RemoveTransitionTags(replacement.Tags);

            TrackAPI.RemoveSegment(segment.id);
            TrackAPI.AddSegment(segment.id, replacement);
            return true;
        }

        private static void EnsureTransitionTags(TrackSegment segment, string sourceNodeId)
        {
            FuseSegment current = TrackAPI.GetSegmentDefinition(segment.id);
            if (current == null)
            {
                return;
            }

            string[] expectedTags = MergeTags(
                current.Tags,
                SourceNodeTagPrefix + sourceNodeId,
                PresetTagPrefix + SpecialWorkPresetIds.DualNarrowBranch);

            if ((current.Tags ?? Array.Empty<string>()).SequenceEqual(expectedTags, StringComparer.OrdinalIgnoreCase))
            {
                return;
            }

            var replacement = Clone(current);
            replacement.Tags = expectedTags;
            TrackAPI.UpdateSegment(segment.id, replacement);
        }

        private static string[] MergeTags(IEnumerable<string> tags, params string[] required)
        {
            var values = new HashSet<string>(
                (tags ?? Enumerable.Empty<string>()).Where(value => !string.IsNullOrWhiteSpace(value)),
                StringComparer.OrdinalIgnoreCase);

            foreach (string value in required.Where(value => !string.IsNullOrWhiteSpace(value)))
            {
                values.RemoveWhere(existing =>
                    existing.StartsWith(SourceNodeTagPrefix, StringComparison.OrdinalIgnoreCase)
                    && value.StartsWith(SourceNodeTagPrefix, StringComparison.OrdinalIgnoreCase)
                    || existing.StartsWith(PresetTagPrefix, StringComparison.OrdinalIgnoreCase)
                    && value.StartsWith(PresetTagPrefix, StringComparison.OrdinalIgnoreCase));
                values.Add(value);
            }

            return values.OrderBy(value => value, StringComparer.OrdinalIgnoreCase).ToArray();
        }

        private static string[] RemoveTransitionTags(IEnumerable<string> tags)
        {
            return (tags ?? Enumerable.Empty<string>())
                .Where(value => !string.IsNullOrWhiteSpace(value))
                .Where(value =>
                    !value.StartsWith(SourceNodeTagPrefix, StringComparison.OrdinalIgnoreCase)
                    && !value.StartsWith(PresetTagPrefix, StringComparison.OrdinalIgnoreCase))
                .OrderBy(value => value, StringComparer.OrdinalIgnoreCase)
                .ToArray();
        }

        private static FuseSegment Clone(FuseSegment source)
        {
            return new FuseSegment
            {
                StartNodeId = source.StartNodeId,
                EndNodeId = source.EndNodeId,
                Style = source.Style,
                TrackClass = source.TrackClass,
                SpeedLimit = source.SpeedLimit,
                Priority = source.Priority,
                GroupId = source.GroupId,
                Tags = source.Tags?.ToArray(),
                Gauge = source.Gauge,
                Partial = source.Partial,
                PreserveStyle = source.PreserveStyle,
                PreserveTrackClass = source.PreserveTrackClass,
                PreserveSpeedLimit = source.PreserveSpeedLimit,
                PreservePriority = source.PreservePriority,
                PreserveGroupId = source.PreserveGroupId
            };
        }

        private static bool IsSegmentOccupied(TrackSegment segment)
        {
            TrainController controller = TrainController.Shared;
            return controller != null
                && controller.Cars.Any(car =>
                    car != null
                    && (car.LocationF.segment == segment
                        || car.LocationR.segment == segment
                        || car.WheelBoundsF.segment == segment
                        || car.WheelBoundsR.segment == segment));
        }
    }
}
