using System;
using System.Collections.Generic;
using System.Linq;
using Core;
using FUSE.Authoring.Data;
using FUSE.Runtime.API;
using Track;
using UnityEngine;

namespace NarrowGaugeMod
{
    /// <summary>
    /// Resolves a continuous physical narrow-gauge centerline through authored
    /// dual-gauge segments. The stored sign is relative to each segment's A-to-B
    /// direction, so reversed segment definitions do not flip the visible rail.
    /// </summary>
    internal static class DualGaugeSharedRailRegistry
    {
        private static readonly Dictionary<string, float> NarrowCenterOffsets =
            new Dictionary<string, float>(StringComparer.OrdinalIgnoreCase);

        public static float OffsetMagnitude =>
            (Gauge.Standard.Inside - NarrowGaugeTrackBuilder.ThreeFootGauge.Inside) * 0.5f;

        public static void Rebuild(Graph graph, IReadOnlyCollection<TrackSegment> dualSegments)
        {
            NarrowCenterOffsets.Clear();
            if (graph == null || dualSegments == null || dualSegments.Count == 0)
            {
                return;
            }

            TrackSegment[] ordered = dualSegments
                .Where(segment => segment?.a != null && segment.b != null)
                .OrderBy(segment => segment.id, StringComparer.OrdinalIgnoreCase)
                .ToArray();
            var byNode = ordered
                .SelectMany(segment => new[]
                {
                    new { Node = segment.a, Segment = segment },
                    new { Node = segment.b, Segment = segment }
                })
                .GroupBy(item => item.Node.id, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(
                    group => group.Key,
                    group => group.Select(item => item.Segment).Distinct().ToArray(),
                    StringComparer.OrdinalIgnoreCase);

            var queue = new Queue<TrackSegment>();
            SeedFromNarrowBranches(graph, ordered, byNode, queue);
            Propagate(byNode, queue);

            foreach (TrackSegment segment in ordered)
            {
                if (NarrowCenterOffsets.ContainsKey(segment.id))
                {
                    continue;
                }

                Assign(segment, OffsetMagnitude, queue);
                Propagate(byNode, queue);
            }
        }

        public static float GetNarrowCenterOffset(TrackSegment? sourceSegment)
        {
            return sourceSegment != null
                && !string.IsNullOrEmpty(sourceSegment.id)
                && NarrowCenterOffsets.TryGetValue(sourceSegment.id, out float offset)
                    ? offset
                    : OffsetMagnitude;
        }

        public static bool SharesRightRail(TrackSegment? sourceSegment)
        {
            return GetNarrowCenterOffset(sourceSegment) >= 0f;
        }

        public static void Clear()
        {
            NarrowCenterOffsets.Clear();
        }

        private static void SeedFromNarrowBranches(
            Graph graph,
            IReadOnlyCollection<TrackSegment> dualSegments,
            IReadOnlyDictionary<string, TrackSegment[]> byNode,
            Queue<TrackSegment> queue)
        {
            foreach (TrackSegment branch in TrackAPI.GetAllSegments()
                .Where(IsRealNarrowOnly)
                .OrderBy(segment => segment.id, StringComparer.OrdinalIgnoreCase))
            {
                string sourceNodeId = SpecialWorkTopologySynchronizer.GetTaggedSourceNodeId(branch);
                if (string.IsNullOrEmpty(sourceNodeId))
                {
                    sourceNodeId = new[] { branch.a, branch.b }
                        .Where(node => node != null)
                        .Select(node => node.id)
                        .FirstOrDefault(id =>
                            byNode.TryGetValue(id, out TrackSegment[] connected)
                            && connected.Length == 2)
                        ?? string.Empty;
                }

                TrackNode sourceNode = graph.GetNode(sourceNodeId);
                if (sourceNode == null
                    || !byNode.TryGetValue(sourceNodeId, out TrackSegment[] connectedDual)
                    || connectedDual.Length != 2
                    || !TryGetBranchDirection(branch, sourceNodeId, out Vector3 branchDirection))
                {
                    continue;
                }

                // The leg opposite the narrow branch is the approach into the
                // transition. V1 seeds the shared rail on the engineer's left
                // while looking from that approach toward the switch.
                TrackSegment approachLeg = connectedDual
                    .OrderBy(segment =>
                        TryDirectionAwayFromNode(segment, sourceNode, out Vector3 direction)
                            ? Vector3.Dot(direction, branchDirection)
                            : 2f)
                    .First();
                if (!TryDirectionAwayFromNode(approachLeg, sourceNode, out Vector3 awayFromSwitch))
                {
                    continue;
                }

                Vector3 towardSwitch = -awayFromSwitch;
                Vector3 up = sourceNode.transform.localRotation * Vector3.up;
                Vector3 right = Vector3.Cross(up, towardSwitch).normalized;
                if (right.sqrMagnitude <= 0.0001f)
                {
                    right = Vector3.Cross(Vector3.up, towardSwitch).normalized;
                }

                Vector3 target = sourceNode.transform.localPosition - right * OffsetMagnitude;

                foreach (TrackSegment segment in connectedDual)
                {
                    float offset = ChooseOffsetClosestTo(segment, sourceNode, target);
                    Assign(segment, offset, queue);
                }
            }
        }

        private static void Propagate(
            IReadOnlyDictionary<string, TrackSegment[]> byNode,
            Queue<TrackSegment> queue)
        {
            while (queue.Count > 0)
            {
                TrackSegment current = queue.Dequeue();
                float currentOffset = GetNarrowCenterOffset(current);

                foreach (TrackNode node in new[] { current.a, current.b })
                {
                    if (node == null
                        || !byNode.TryGetValue(node.id, out TrackSegment[] neighbors)
                        || !TryOffsetPosition(current, node, currentOffset, out Vector3 target))
                    {
                        continue;
                    }

                    foreach (TrackSegment neighbor in neighbors)
                    {
                        if (neighbor == current || NarrowCenterOffsets.ContainsKey(neighbor.id))
                        {
                            continue;
                        }

                        Assign(neighbor, ChooseOffsetClosestTo(neighbor, node, target), queue);
                    }
                }
            }
        }

        private static void Assign(TrackSegment segment, float offset, Queue<TrackSegment> queue)
        {
            if (segment == null
                || string.IsNullOrEmpty(segment.id)
                || NarrowCenterOffsets.ContainsKey(segment.id))
            {
                return;
            }

            NarrowCenterOffsets[segment.id] = offset >= 0f ? OffsetMagnitude : -OffsetMagnitude;
            queue.Enqueue(segment);
        }

        private static float ChooseOffsetClosestTo(
            TrackSegment segment,
            TrackNode node,
            Vector3 target)
        {
            bool hasPositive = TryOffsetPosition(segment, node, OffsetMagnitude, out Vector3 positive);
            bool hasNegative = TryOffsetPosition(segment, node, -OffsetMagnitude, out Vector3 negative);
            if (!hasPositive)
            {
                return -OffsetMagnitude;
            }

            if (!hasNegative)
            {
                return OffsetMagnitude;
            }

            return Vector3.Distance(positive, target) <= Vector3.Distance(negative, target)
                ? OffsetMagnitude
                : -OffsetMagnitude;
        }

        private static bool TryOffsetPosition(
            TrackSegment segment,
            TrackNode node,
            float offset,
            out Vector3 position)
        {
            position = Vector3.zero;
            if (!TryDirectionAtoBAtNode(segment, node, out Vector3 directionAtoB, out Vector3 anchor))
            {
                return false;
            }

            Vector3 up = node.transform.localRotation * Vector3.up;
            Vector3 right = Vector3.Cross(up, directionAtoB).normalized;
            if (right.sqrMagnitude <= 0.0001f)
            {
                right = Vector3.Cross(Vector3.up, directionAtoB).normalized;
            }

            position = anchor + right * offset;
            return true;
        }

        private static bool TryDirectionAwayFromNode(
            TrackSegment segment,
            TrackNode node,
            out Vector3 direction)
        {
            direction = Vector3.zero;
            if (!TryDirectionAtoBAtNode(segment, node, out Vector3 directionAtoB, out _))
            {
                return false;
            }

            direction = segment.a == node ? directionAtoB : -directionAtoB;
            return true;
        }

        private static bool TryDirectionAtoBAtNode(
            TrackSegment segment,
            TrackNode node,
            out Vector3 direction,
            out Vector3 anchor)
        {
            direction = Vector3.zero;
            anchor = Vector3.zero;
            if (segment == null || node == null)
            {
                return false;
            }

            LinePoint[] points = segment.Curve
                .Approximate(1.000005f, 0.25f, 16, 40f)
                .ToArray();
            if (points.Length < 2)
            {
                return false;
            }

            bool atStart = segment.a == node;
            anchor = atStart ? points[0].point : points[points.Length - 1].point;
            Vector3 neighbor = atStart ? points[1].point : points[points.Length - 2].point;
            direction = atStart ? neighbor - anchor : anchor - neighbor;
            if (direction.sqrMagnitude <= 0.000001f)
            {
                return false;
            }

            direction.Normalize();
            return true;
        }

        private static bool TryGetBranchDirection(
            TrackSegment branch,
            string sourceNodeId,
            out Vector3 direction)
        {
            direction = Vector3.zero;
            TrackNode endpoint = new[] { branch.a, branch.b }
                .FirstOrDefault(node =>
                    node != null
                    && (string.Equals(node.id, sourceNodeId, StringComparison.OrdinalIgnoreCase)
                        || string.Equals(
                            node.id,
                            GhostGraphSynchronizer.GetGhostNodeId(sourceNodeId),
                            StringComparison.OrdinalIgnoreCase)));
            return endpoint != null && TryDirectionAwayFromNode(branch, endpoint, out direction);
        }

        private static bool IsRealNarrowOnly(TrackSegment segment)
        {
            if (segment == null || GhostGraphSynchronizer.IsGeneratedGhostSegmentId(segment.id))
            {
                return false;
            }

            FuseSegment definition = TrackAPI.GetSegmentDefinition(segment.id);
            return GhostGraphSynchronizer.IsNarrowGaugeDefinition(definition)
                && !GhostGraphSynchronizer.IsDualGaugeDefinition(definition);
        }
    }
}
